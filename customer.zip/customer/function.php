<?php
require 'connect.php';
if(isset($_POST["action"])){
    if($_POST["action"] == "insert"){
      insert();
    }
  else if($_POST["action"] == "edit"){
    edit();
  }
  else{
    delete();
  }
}

function insert(){
  global $conn;

  $id_booking = $_POST["id_booking"];
  $Username = $_POST["Username"];
  $name_car = $_POST["name_car"];
  $pdate = $_POST["pdate"];
  $rdate = $_POST["rdate"];
  $Phone = $_POST["Phone"];

  $query = "INSERT INTO booking VALUES('', '$Username', '$name_car', '$pdate','$rdate','$Phone')";
  mysqli_query($conn, $query);
  echo "Inserted Successfully";
}


function edit(){
  global $conn;

  $id_booking = $_POST["id_booking"];
  $Username = $_POST["Username"];
  $name_car = $_POST["name_car"];
  $pdate = $_POST["pdate"];
  $rdate = $_POST["rdate"];
  $Phone = $_POST["Phone"];

  $query = "UPDATE booking SET Username = '$Username', name_car = '$name_car', pdate = '$pdate',rdate = '$rdate',Phone = '$Phone' ";
  mysqli_query($conn, $query);
  echo "Updated Successfully";
}

function delete(){
  global $conn;

  $id_booking = $_POST["action"];

  $query = "DELETE FROM booking WHERE id_booking = $id_booking";
  mysqli_query($conn, $query);
  echo "Deleted Successfully";
}